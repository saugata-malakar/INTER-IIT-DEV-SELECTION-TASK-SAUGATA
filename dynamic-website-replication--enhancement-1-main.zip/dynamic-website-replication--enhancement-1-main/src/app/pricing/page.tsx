"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "@/lib/auth-client";
import { PricingTable } from "@/components/autumn/pricing-table";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

const productDetails = [
  {
    id: "free",
    description: "Perfect for getting started with commenting",
    items: [
      {
        featureId: "comments",
        primaryText: "10 comments per month",
        secondaryText: "Great for casual users",
      },
      {
        primaryText: "Threaded replies",
        secondaryText: "Nested comment threads",
      },
      {
        primaryText: "Upvote comments",
        secondaryText: "Show support for comments",
      },
    ],
  },
  {
    id: "pro",
    description: "For active community members",
    recommendText: "Most Popular",
    price: {
      primaryText: "$9.99/month",
      secondaryText: "billed monthly",
    },
    items: [
      {
        featureId: "comments",
        primaryText: "100 comments per month",
        secondaryText: "More than enough for most users",
      },
      {
        featureId: "comment_editing",
        primaryText: "Edit your comments",
        secondaryText: "Fix typos and update content",
      },
      {
        primaryText: "All Free features",
        secondaryText: "Everything from the free plan",
      },
      {
        primaryText: "Priority support",
        secondaryText: "Get help faster",
      },
    ],
  },
  {
    id: "premium",
    description: "For community moderators and power users",
    price: {
      primaryText: "$19.99/month",
      secondaryText: "billed monthly",
    },
    items: [
      {
        featureId: "comments",
        primaryText: "Unlimited comments",
        secondaryText: "Comment as much as you want",
      },
      {
        featureId: "comment_editing",
        primaryText: "Edit your comments",
        secondaryText: "Fix typos and update content",
      },
      {
        featureId: "admin_controls",
        primaryText: "Admin controls",
        secondaryText: "Delete any comment for moderation",
      },
      {
        primaryText: "All Pro features",
        secondaryText: "Everything from Pro plan",
      },
      {
        primaryText: "Premium support",
        secondaryText: "Dedicated support channel",
      },
    ],
  },
];

export default function PricingPage() {
  const { data: session } = useSession();
  const router = useRouter();

  // If user tries to checkout/upgrade but not logged in, redirect to login
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("plan") && !session) {
      router.push(`/login?redirect=${encodeURIComponent(window.location.pathname + window.location.search)}`);
    }
  }, [session, router]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-background/70 border-b border-border">
        <div className="mx-auto max-w-7xl px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-8 w-8 overflow-hidden rounded-md">
              <Image src="https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?w=200&q=80" alt="logo" fill sizes="32px" className="object-cover" />
            </div>
            <span className="font-semibold tracking-tight">Bridge Comments</span>
          </div>
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-1" /> Back to Home
            </Button>
          </Link>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-[radial-gradient(70%_120%_at_50%_-20%,_rgba(0,0,0,0.06),_transparent)]">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:py-20 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight">
            Choose Your Plan
          </h1>
          <p className="text-muted-foreground mt-4 text-lg max-w-2xl mx-auto">
            Start free and upgrade anytime. All plans include our core commenting features.
          </p>
        </div>
      </section>

      {/* Pricing Table */}
      <main className="mx-auto max-w-7xl px-4 pb-20">
        <PricingTable productDetails={productDetails} />
      </main>

      {/* FAQ Section */}
      <section className="mx-auto max-w-4xl px-4 pb-20">
        <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
        <div className="space-y-6">
          <div className="border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-2">Can I change my plan anytime?</h3>
            <p className="text-muted-foreground">
              Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately.
            </p>
          </div>
          <div className="border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-2">What happens if I reach my comment limit?</h3>
            <p className="text-muted-foreground">
              You'll be prompted to upgrade to continue commenting. Your existing comments remain visible.
            </p>
          </div>
          <div className="border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-2">How do comment limits reset?</h3>
            <p className="text-muted-foreground">
              Comment limits reset monthly on the same day you signed up or upgraded.
            </p>
          </div>
          <div className="border border-border rounded-lg p-6">
            <h3 className="font-semibold mb-2">What are admin controls?</h3>
            <p className="text-muted-foreground">
              Admin controls allow Premium users to delete any comment for moderation purposes, not just their own.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}