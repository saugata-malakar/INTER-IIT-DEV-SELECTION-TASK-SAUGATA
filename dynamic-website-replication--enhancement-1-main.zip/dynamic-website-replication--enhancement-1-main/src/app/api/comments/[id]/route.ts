import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { comments, users } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { z } from 'zod';

const patchCommentSchema = z.object({
  text: z.string().min(1, 'Text is required').max(5000, 'Text must not exceed 5000 characters'),
  userId: z.number().int().positive('Valid user ID is required'),
});

const deleteCommentSchema = z.object({
  userId: z.number().int().positive('Valid user ID is required'),
});

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const id = params.id;

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json(
        { error: 'Valid comment ID is required', code: 'INVALID_ID' },
        { status: 400 }
      );
    }

    const commentId = parseInt(id);

    const body = await request.json();
    const validation = patchCommentSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { 
          error: validation.error.errors[0].message,
          code: 'VALIDATION_ERROR',
          details: validation.error.errors 
        },
        { status: 400 }
      );
    }

    const { text, userId } = validation.data;

    const existingComment = await db
      .select()
      .from(comments)
      .where(eq(comments.id, commentId))
      .limit(1);

    if (existingComment.length === 0) {
      return NextResponse.json(
        { error: 'Comment not found', code: 'COMMENT_NOT_FOUND' },
        { status: 404 }
      );
    }

    const comment = existingComment[0];

    if (comment.userId !== userId) {
      return NextResponse.json(
        { 
          error: 'You do not have permission to edit this comment',
          code: 'FORBIDDEN' 
        },
        { status: 403 }
      );
    }

    const trimmedText = text.trim();

    const updatedComment = await db
      .update(comments)
      .set({
        text: trimmedText,
      })
      .where(eq(comments.id, commentId))
      .returning();

    if (updatedComment.length === 0) {
      return NextResponse.json(
        { error: 'Failed to update comment', code: 'UPDATE_FAILED' },
        { status: 500 }
      );
    }

    return NextResponse.json(updatedComment[0], { status: 200 });
  } catch (error) {
    console.error('PATCH /api/comments/[id] error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + error },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const id = params.id;

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json(
        { error: 'Valid comment ID is required', code: 'INVALID_ID' },
        { status: 400 }
      );
    }

    const commentId = parseInt(id);

    const body = await request.json();
    const validation = deleteCommentSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { 
          error: validation.error.errors[0].message,
          code: 'VALIDATION_ERROR',
          details: validation.error.errors 
        },
        { status: 400 }
      );
    }

    const { userId } = validation.data;

    const existingComment = await db
      .select()
      .from(comments)
      .where(eq(comments.id, commentId))
      .limit(1);

    if (existingComment.length === 0) {
      return NextResponse.json(
        { error: 'Comment not found', code: 'COMMENT_NOT_FOUND' },
        { status: 404 }
      );
    }

    const comment = existingComment[0];

    const userRecord = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (userRecord.length === 0) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 404 }
      );
    }

    const user = userRecord[0];

    const isOwner = comment.userId === userId;
    const isAdmin = user.isAdmin === true;

    if (!isOwner && !isAdmin) {
      return NextResponse.json(
        { 
          error: 'You do not have permission to delete this comment',
          code: 'FORBIDDEN' 
        },
        { status: 403 }
      );
    }

    const deletedComment = await db
      .update(comments)
      .set({
        text: '[deleted]',
      })
      .where(eq(comments.id, commentId))
      .returning();

    if (deletedComment.length === 0) {
      return NextResponse.json(
        { error: 'Failed to delete comment', code: 'DELETE_FAILED' },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { success: true, message: 'Comment deleted' },
      { status: 200 }
    );
  } catch (error) {
    console.error('DELETE /api/comments/[id] error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + error },
      { status: 500 }
    );
  }
}