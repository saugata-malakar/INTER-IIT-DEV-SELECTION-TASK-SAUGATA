import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { comments, commentUpvotes } from '@/db/schema';
import { eq, and, sql } from 'drizzle-orm';
import { z } from 'zod';
import { ensureSchema } from '@/db';

const upvoteSchema = z.object({
  userId: z.number().positive('User ID must be a positive number')
});

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await ensureSchema();
    const { id } = params;

    // Validate comment ID
    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json(
        { 
          error: 'Valid comment ID is required',
          code: 'INVALID_ID' 
        },
        { status: 400 }
      );
    }

    const commentId = parseInt(id);

    // Parse and validate request body
    let body;
    try {
      body = await request.json();
    } catch (error) {
      return NextResponse.json(
        { 
          error: 'Invalid JSON in request body',
          code: 'INVALID_JSON' 
        },
        { status: 400 }
      );
    }

    const validation = upvoteSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        { 
          error: validation.error.errors[0].message,
          code: 'VALIDATION_ERROR',
          details: validation.error.errors
        },
        { status: 400 }
      );
    }

    const { userId } = validation.data;

    // Verify comment exists
    const existingComment = await db.select()
      .from(comments)
      .where(eq(comments.id, commentId))
      .limit(1);

    if (existingComment.length === 0) {
      return NextResponse.json(
        { 
          error: 'Comment not found',
          code: 'COMMENT_NOT_FOUND' 
        },
        { status: 404 }
      );
    }

    // Check if upvote already exists
    const existingUpvote = await db.select()
      .from(commentUpvotes)
      .where(
        and(
          eq(commentUpvotes.commentId, commentId),
          eq(commentUpvotes.userId, userId)
        )
      )
      .limit(1);

    const upvoteExists = existingUpvote.length > 0;

    // Toggle upvote behavior
    if (upvoteExists) {
      // Remove upvote - decrement count
      await db.delete(commentUpvotes)
        .where(
          and(
            eq(commentUpvotes.commentId, commentId),
            eq(commentUpvotes.userId, userId)
          )
        );

      await db.update(comments)
        .set({ upvotes: sql`${comments.upvotes} - 1` })
        .where(eq(comments.id, commentId));
    } else {
      // Add upvote - increment count
      await db.insert(commentUpvotes)
        .values({
          commentId,
          userId,
          createdAt: new Date().toISOString()
        });

      await db.update(comments)
        .set({ upvotes: sql`${comments.upvotes} + 1` })
        .where(eq(comments.id, commentId));
    }

    // Get updated comment to return current upvotes count
    const updatedComment = await db.select()
      .from(comments)
      .where(eq(comments.id, commentId))
      .limit(1);

    return NextResponse.json({
      upvoted: !upvoteExists,
      upvotes: updatedComment[0].upvotes || 0
    });

  } catch (error) {
    console.error('POST /api/comments/[id]/upvote error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error: ' + error
      },
      { status: 500 }
    );
  }
}