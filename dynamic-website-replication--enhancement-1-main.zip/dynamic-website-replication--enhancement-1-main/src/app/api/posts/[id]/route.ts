import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { posts, comments } from '@/db/schema';
import { eq, count } from 'drizzle-orm';
import { ensureSchema } from '@/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await ensureSchema();
    const { id } = params;

    // Validate ID is a valid integer
    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json(
        { 
          error: 'Valid ID is required',
          code: 'INVALID_ID'
        },
        { status: 400 }
      );
    }

    const postId = parseInt(id);

    // Query the post by ID
    const postResult = await db
      .select()
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);

    // Return 404 if post not found
    if (postResult.length === 0) {
      return NextResponse.json(
        { 
          error: 'Post not found',
          code: 'POST_NOT_FOUND'
        },
        { status: 404 }
      );
    }

    const post = postResult[0];

    // Count total comments for this post
    const commentCountResult = await db
      .select({ count: count() })
      .from(comments)
      .where(eq(comments.postId, postId));

    const commentCount = commentCountResult[0]?.count || 0;

    // Return post with comment count
    return NextResponse.json({
      id: post.id,
      title: post.title,
      coverUrl: post.coverUrl,
      content: post.content,
      createdAt: post.createdAt,
      commentCount: commentCount
    }, { status: 200 });

  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json(
      { 
        error: 'Internal server error: ' + error
      },
      { status: 500 }
    );
  }
}