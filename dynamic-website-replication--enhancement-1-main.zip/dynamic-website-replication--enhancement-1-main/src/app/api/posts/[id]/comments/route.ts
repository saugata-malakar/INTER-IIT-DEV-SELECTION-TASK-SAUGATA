import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { comments, users, posts } from '@/db/schema';
import { eq, desc, and, sql } from 'drizzle-orm';
import { z } from 'zod';
import { ensureSchema } from '@/db';

interface CommentWithUser {
  id: number;
  postId: number;
  parentId: number | null;
  userId: number;
  text: string;
  upvotes: number;
  createdAt: string;
  user: {
    id: number;
    name: string;
    avatar: string | null;
  };
  replies: CommentWithUser[];
}

interface FlatComment {
  id: number;
  postId: number;
  parentId: number | null;
  userId: number;
  text: string;
  upvotes: number;
  createdAt: string;
  userName: string;
  userAvatar: string | null;
}

function countDescendants(commentId: number, allComments: FlatComment[]): number {
  const children = allComments.filter(c => c.parentId === commentId);
  let count = children.length;
  
  for (const child of children) {
    count += countDescendants(child.id, allComments);
  }
  
  return count;
}

function buildCommentTree(
  flatComments: FlatComment[],
  sortType: 'top' | 'new' | 'replies',
  parentId: number | null = null
): CommentWithUser[] {
  const children = flatComments.filter(c => c.parentId === parentId);
  
  let sortedChildren = [...children];
  
  if (sortType === 'top') {
    sortedChildren.sort((a, b) => {
      if (b.upvotes !== a.upvotes) {
        return b.upvotes - a.upvotes;
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  } else if (sortType === 'new') {
    sortedChildren.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } else if (sortType === 'replies') {
    sortedChildren.sort((a, b) => {
      const aDescendants = countDescendants(a.id, flatComments);
      const bDescendants = countDescendants(b.id, flatComments);
      return bDescendants - aDescendants;
    });
  }
  
  return sortedChildren.map(comment => ({
    id: comment.id,
    postId: comment.postId,
    parentId: comment.parentId,
    userId: comment.userId,
    text: comment.text,
    upvotes: comment.upvotes,
    createdAt: comment.createdAt,
    user: {
      id: comment.userId,
      name: comment.userName,
      avatar: comment.userAvatar,
    },
    replies: buildCommentTree(flatComments, sortType, comment.id),
  }));
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await ensureSchema();
    const { id } = params;
    const postId = parseInt(id);
    
    if (isNaN(postId)) {
      return NextResponse.json(
        { error: 'Valid post ID is required', code: 'INVALID_ID' },
        { status: 400 }
      );
    }
    
    const searchParams = request.nextUrl.searchParams;
    const sortParam = searchParams.get('sort') || 'top';
    const sortType = ['top', 'new', 'replies'].includes(sortParam) 
      ? sortParam as 'top' | 'new' | 'replies'
      : 'top';
    
    const postExists = await db.select()
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);
    
    if (postExists.length === 0) {
      return NextResponse.json(
        { error: 'Post not found', code: 'POST_NOT_FOUND' },
        { status: 404 }
      );
    }
    
    const flatComments = await db.select({
      id: comments.id,
      postId: comments.postId,
      parentId: comments.parentId,
      userId: comments.userId,
      text: comments.text,
      upvotes: comments.upvotes,
      createdAt: comments.createdAt,
      userName: users.name,
      userAvatar: users.avatar,
    })
      .from(comments)
      .innerJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.postId, postId));
    
    const nestedComments = buildCommentTree(flatComments, sortType);
    
    return NextResponse.json(nestedComments);
  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + error },
      { status: 500 }
    );
  }
}

const commentSchema = z.object({
  text: z.string().min(1, 'Text is required').max(5000, 'Text must not exceed 5000 characters'),
  parentId: z.number().nullable().optional(),
  userId: z.number({ required_error: 'User ID is required' }),
});

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await ensureSchema();
    const { id } = params;
    const postId = parseInt(id);
    
    if (isNaN(postId)) {
      return NextResponse.json(
        { error: 'Valid post ID is required', code: 'INVALID_ID' },
        { status: 400 }
      );
    }
    
    const postExists = await db.select()
      .from(posts)
      .where(eq(posts.id, postId))
      .limit(1);
    
    if (postExists.length === 0) {
      return NextResponse.json(
        { error: 'Post not found', code: 'POST_NOT_FOUND' },
        { status: 404 }
      );
    }
    
    const body = await request.json();
    
    const validation = commentSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json(
        { 
          error: validation.error.errors[0].message,
          code: 'VALIDATION_ERROR',
          details: validation.error.errors 
        },
        { status: 400 }
      );
    }
    
    const { text, parentId, userId } = validation.data;
    
    if (parentId !== null && parentId !== undefined) {
      const parentComment = await db.select()
        .from(comments)
        .where(eq(comments.id, parentId))
        .limit(1);
      
      if (parentComment.length === 0) {
        return NextResponse.json(
          { error: 'Parent comment not found', code: 'PARENT_NOT_FOUND' },
          { status: 400 }
        );
      }
      
      if (parentComment[0].postId !== postId) {
        return NextResponse.json(
          { 
            error: 'Parent comment does not belong to this post', 
            code: 'PARENT_POST_MISMATCH' 
          },
          { status: 400 }
        );
      }
    }
    
    const userExists = await db.select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    
    if (userExists.length === 0) {
      return NextResponse.json(
        { error: 'User not found', code: 'USER_NOT_FOUND' },
        { status: 400 }
      );
    }
    
    const newComment = await db.insert(comments)
      .values({
        postId,
        parentId: parentId ?? null,
        userId,
        text: text.trim(),
        upvotes: 0,
        createdAt: new Date().toISOString(),
      })
      .returning();
    
    const user = userExists[0];
    
    const responseComment = {
      id: newComment[0].id,
      postId: newComment[0].postId,
      parentId: newComment[0].parentId,
      userId: newComment[0].userId,
      text: newComment[0].text,
      upvotes: newComment[0].upvotes,
      createdAt: newComment[0].createdAt,
      user: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
      },
      replies: [],
    };
    
    return NextResponse.json(responseComment, { status: 201 });
  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + error },
      { status: 500 }
    );
  }
}