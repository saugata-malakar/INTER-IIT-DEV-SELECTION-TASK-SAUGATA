import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { signToken } from "@/lib/jwt";
import { ensureSchema } from "@/db";

const ALLOWED_DOMAINS = ["example.com"]; // domain-gated auth per spec

export async function POST(req: NextRequest) {
  try {
    await ensureSchema();
    const body = await req.json();
    const email: string | undefined = body?.email?.toLowerCase();
    const name: string | undefined = body?.name;

    if (!email) {
      return NextResponse.json({ error: "Email is required" }, { status: 400 });
    }

    const domain = email.split("@")[1];
    if (!domain || !ALLOWED_DOMAINS.includes(domain)) {
      return NextResponse.json({ error: "Email domain not allowed" }, { status: 403 });
    }

    let user = (await db.select().from(users).where(eq(users.email, email)).limit(1))[0];

    if (!user) {
      // auto-register minimal user on first login
      const inserted = await db
        .insert(users)
        .values({
          name: name || email.split("@")[0],
          email,
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(email)}`,
          isAdmin: email.startsWith("admin@"),
          createdAt: new Date().toISOString(),
        })
        .returning();
      user = inserted[0];
    }

    const token = signToken({ id: user.id, email: user.email, name: user.name, isAdmin: !!user.isAdmin });

    return NextResponse.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        isAdmin: !!user.isAdmin,
      },
    });
  } catch (e) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}