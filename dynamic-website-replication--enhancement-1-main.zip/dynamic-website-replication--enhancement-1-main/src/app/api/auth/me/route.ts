import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/jwt";

export async function GET(req: NextRequest) {
  const auth = req.headers.get("authorization") || req.headers.get("Authorization");
  const token = auth?.startsWith("Bearer ") ? auth.slice(7) : undefined;

  if (!token) return NextResponse.json({ user: null }, { status: 200 });

  const payload = verifyToken(token);
  if (!payload) return NextResponse.json({ user: null }, { status: 200 });

  return NextResponse.json({ user: payload }, { status: 200 });
}