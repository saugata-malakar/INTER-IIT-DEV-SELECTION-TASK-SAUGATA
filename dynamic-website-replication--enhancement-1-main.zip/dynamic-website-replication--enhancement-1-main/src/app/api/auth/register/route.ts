import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email: string | undefined = body?.email?.toLowerCase();
    const name: string | undefined = body?.name;
    const avatar: string | undefined = body?.avatar;

    if (!email || !name) {
      return NextResponse.json({ error: "Name and email are required" }, { status: 400 });
    }

    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing[0]) {
      return NextResponse.json({ error: "User already exists" }, { status: 409 });
    }

    const inserted = await db
      .insert(users)
      .values({
        name,
        email,
        avatar: avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(email)}`,
        isAdmin: email.startsWith("admin@"),
        createdAt: new Date().toISOString(),
      })
      .returning();

    return NextResponse.json({ user: inserted[0] }, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
}