"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronDown, ChevronRight, LogIn, LogOut, ArrowBigUp, MessageSquare, Trash2, Crown, Zap } from "lucide-react";
import { useRouter } from "next/navigation";
import { authClient, useSession } from "@/lib/auth-client";
import { toast } from "sonner";
import { useCustomer } from "autumn-js/react";
import Link from "next/link";

type User = {
  id: number;
  name: string;
  email: string;
  avatar: string | null;
  isAdmin?: boolean;
};

export type CommentNode = {
  id: number;
  postId: number;
  parentId: number | null;
  userId: number;
  text: string;
  upvotes: number;
  createdAt: string;
  user: { id: number; name: string; avatar: string | null };
  replies: CommentNode[];
};

function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const router = useRouter();
  useEffect(() => {
    try {
      const raw = localStorage.getItem("user");
      if (raw) setUser(JSON.parse(raw));
    } catch {}
  }, []);
  // verify token with backend and sync user on mount
  useEffect(() => {
    const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;
    if (!token) return;
    fetch("/api/auth/me", { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => res.json())
      .then((data) => {
        if (!data?.user) {
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          setUser(null);
        } else {
          localStorage.setItem("user", JSON.stringify(data.user));
          setUser(data.user);
        }
      })
      .catch(() => {});
  }, []);
  const signOut = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
    router.push("/");
  };
  return { user, signOut };
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const d = Math.floor(hr / 24);
  return `${d}d ago`;
}

export default function HomePage() {
  const { data: session, isPending } = useSession();
  const user = session?.user;
  const { customer, check, track, refetch, isLoading: customerLoading } = useCustomer();
  const router = useRouter();
  const [post, setPost] = useState<{ id: number; title: string; coverUrl: string | null; content: string; createdAt: string; commentCount: number } | null>(null);
  const [comments, setComments] = useState<CommentNode[]>([]);
  const [sort, setSort] = useState<"top" | "new" | "replies">("top");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newComment, setNewComment] = useState("");

  const postId = 1;

  const signOut = async () => {
    const token = localStorage.getItem("bearer_token");
    const { error } = await authClient.signOut({
      fetchOptions: {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
    });
    if (error?.code) {
      toast.error(error.code);
    } else {
      localStorage.removeItem("bearer_token");
      router.push("/");
    }
  };

  const load = async () => {
    try {
      setLoading(true);
      setError(null);
      const token = typeof window !== "undefined" ? localStorage.getItem("bearer_token") : null;
      const headers: HeadersInit = token ? { Authorization: `Bearer ${token}` } : {};
      const [pRes, cRes] = await Promise.all([
        fetch(`/api/posts/${postId}`, { headers }),
        fetch(`/api/posts/${postId}/comments?sort=${sort}`, { headers }),
      ]);
      if (!pRes.ok) throw new Error("Failed to load post");
      if (!cRes.ok) throw new Error("Failed to load comments");
      const p = await pRes.json();
      const c = await cRes.json();
      setPost(p);
      setComments(c);
    } catch (e: any) {
      setError(e.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sort]);

  const handleCreate = async () => {
    if (!user) return router.push("/login");
    if (!newComment.trim()) return;

    // Feature gate: Check if user can create comments
    const { data } = await check({ featureId: "comments", requiredBalance: 1 });
    if (!data.allowed) {
      toast.error("You've reached your comment limit. Please upgrade your plan.");
      router.push("/pricing");
      return;
    }

    const token = typeof window !== "undefined" ? localStorage.getItem("bearer_token") : null;
    const res = await fetch(`/api/posts/${postId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ text: newComment.trim(), userId: user.id, parentId: null }),
    });
    
    if (res.ok) {
      setNewComment("");
      // Track usage
      await track({ featureId: "comments", value: 1, idempotencyKey: `comment-${Date.now()}` });
      await refetch();
      await load();
      toast.success("Comment posted!");
    }
  };

  // Get current plan and usage
  const currentPlan = customer?.products?.[0];
  const planName = currentPlan?.name || "Free";
  const commentsFeature = customer?.features?.comments;
  const commentsUsage = commentsFeature?.usage || 0;
  const commentsLimit = commentsFeature?.included_usage || 0;
  const hasUnlimitedComments = commentsFeature?.unlimited || false;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-background/70 border-b border-border">
        <div className="mx-auto max-w-5xl px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-8 w-8 overflow-hidden rounded-md">
              <Image src="https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?w=200&q=80" alt="logo" fill sizes="32px" className="object-cover" />
            </div>
            <span className="font-semibold tracking-tight">Bridge Comments</span>
          </div>
          <div className="flex items-center gap-2">
            {/* Pricing Link */}
            <Link href="/pricing">
              <Button variant="ghost" size="sm" className="hidden md:flex">
                Pricing
              </Button>
            </Link>
            
            {user ? (
              <>
                {/* Plan Badge - Always Visible */}
                <Link href="/pricing" className="flex">
                  <div className="px-2.5 py-1 text-xs font-medium rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors flex items-center gap-1">
                    {planName === "Premium" && <Crown className="h-3 w-3" />}
                    {planName === "Pro" && <Zap className="h-3 w-3" />}
                    {planName}
                  </div>
                </Link>
                <div className="hidden sm:flex items-center gap-2 pr-2 text-sm text-muted-foreground">
                  <span className="truncate max-w-[140px]">{user.name}</span>
                </div>
                <Button variant="secondary" size="sm" onClick={signOut}>
                  <LogOut className="h-4 w-4 mr-1" /> Sign out
                </Button>
              </>
            ) : (
              <Button size="sm" onClick={() => router.push("/login")}>
                <LogIn className="h-4 w-4 mr-1" /> Sign in
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Hero */}
      <section className="bg-[radial-gradient(70%_120%_at_50%_-20%,_rgba(0,0,0,0.06),_transparent)]">
        <div className="mx-auto max-w-5xl px-4 py-10 sm:py-14">
          <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="text-3xl sm:text-4xl font-semibold tracking-tight">
            A modern, nested comments experience
          </motion.h1>
          <p className="text-muted-foreground mt-2 max-w-2xl">
            Threaded replies, sorting, voting, and admin controls — optimized for clarity and speed.
          </p>
        </div>
      </section>

      <main className="mx-auto max-w-5xl px-4 pb-16 space-y-6">
        {/* Usage Display - Only show when logged in */}
        {user && !customerLoading && (
          <Card className="bg-gradient-to-br from-primary/5 to-transparent">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">Your Plan: {planName}</CardTitle>
                  <CardDescription className="text-sm mt-1">
                    {hasUnlimitedComments 
                      ? "Unlimited comments" 
                      : `${commentsUsage} of ${commentsLimit} comments used this month`}
                  </CardDescription>
                </div>
                <Link href="/pricing">
                  <Button size="sm" variant="outline">
                    {planName === "Free" ? "Upgrade" : "Manage Plan"}
                  </Button>
                </Link>
              </div>
            </CardHeader>
            {!hasUnlimitedComments && (
              <CardContent className="pt-0">
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className={`h-2 rounded-full transition-all ${
                      (commentsUsage / commentsLimit) > 0.9 ? "bg-destructive" : 
                      (commentsUsage / commentsLimit) > 0.75 ? "bg-yellow-500" : "bg-primary"
                    }`}
                    style={{ width: `${Math.min(100, (commentsUsage / commentsLimit) * 100)}%` }}
                  />
                </div>
              </CardContent>
            )}
          </Card>
        )}

        {/* Post */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between gap-4">
              <span>{post?.title ?? "Loading post..."}</span>
              <Select value={sort} onValueChange={(v) => setSort(v as any)}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="top">Top (upvotes)</SelectItem>
                  <SelectItem value="new">Newest</SelectItem>
                  <SelectItem value="replies">Most Replies</SelectItem>
                </SelectContent>
              </Select>
            </CardTitle>
            <CardDescription>
              {post && (
                <span>
                  {new Date(post.createdAt).toLocaleDateString()} • {post.commentCount} comments
                </span>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative w-full h-56 sm:h-72 rounded-lg overflow-hidden">
              <Image
                src={post?.coverUrl || "https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=1200"}
                alt="cover"
                fill
                priority
                sizes="(max-width:768px) 100vw, 896px"
                className="object-cover"
              />
            </div>
            <p className="leading-7 text-[15px] text-foreground/90">
              {post?.content ?? ""}
            </p>
          </CardContent>
        </Card>

        {/* New comment */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Add a comment</CardTitle>
            <CardDescription>Share your thoughts about this post.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea
              placeholder={user ? "Write your comment..." : "Sign in to join the discussion"}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              disabled={!user}
            />
            <div className="flex justify-end">
              <Button onClick={handleCreate} disabled={!user || !newComment.trim()}>
                Post comment
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Comments */}
        <section className="space-y-4">
          <h2 className="text-xl font-semibold">Comments</h2>
          {loading && <p className="text-muted-foreground">Loading comments…</p>}
          {error && <p className="text-red-600">{error}</p>}
          {!loading && comments.length === 0 && (
            <p className="text-muted-foreground">Be the first to comment!</p>
          )}
          <div className="space-y-3">
            {comments.map((c) => (
              <CommentItem key={c.id} node={c} depth={0} onChanged={load} currentUser={user} customer={customer} checkFeature={check} trackUsage={track} refetchCustomer={refetch} />
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

function CommentItem({ node, depth, onChanged, currentUser, customer, checkFeature, trackUsage, refetchCustomer }: { 
  node: CommentNode; 
  depth: number; 
  onChanged: () => void; 
  currentUser: any;
  customer: any;
  checkFeature: any;
  trackUsage: any;
  refetchCustomer: any;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [replying, setReplying] = useState(false);
  const [replyText, setReplyText] = useState("");
  const [busy, setBusy] = useState(false);
  const isOwner = currentUser?.id === node.userId;
  const hasAdminControls = customer?.features?.admin_controls !== undefined;
  const canDelete = isOwner || hasAdminControls;
  const router = useRouter();

  const indentStyle = useMemo(() => ({ paddingLeft: `${Math.min(depth, 6) * 16}px` }), [depth]);

  const upvote = async () => {
    if (!currentUser) return router.push("/login");
    setBusy(true);
    const token = typeof window !== "undefined" ? localStorage.getItem("bearer_token") : null;
    await fetch(`/api/comments/${node.id}/upvote`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ userId: currentUser.id }),
    });
    setBusy(false);
    onChanged();
  };

  const submitReply = async () => {
    if (!currentUser || !replyText.trim()) return;

    // Feature gate: Check if user can create comments (replies count as comments)
    const { data } = await checkFeature({ featureId: "comments", requiredBalance: 1 });
    if (!data.allowed) {
      toast.error("You've reached your comment limit. Please upgrade your plan.");
      router.push("/pricing");
      return;
    }

    setBusy(true);
    const token = typeof window !== "undefined" ? localStorage.getItem("bearer_token") : null;
    const res = await fetch(`/api/posts/${node.postId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ text: replyText.trim(), userId: currentUser.id, parentId: node.id }),
    });
    
    if (res.ok) {
      setReplyText("");
      setReplying(false);
      // Track usage
      await trackUsage({ featureId: "comments", value: 1, idempotencyKey: `reply-${Date.now()}` });
      await refetchCustomer();
      toast.success("Reply posted!");
    }
    setBusy(false);
    onChanged();
  };

  const remove = async () => {
    if (!currentUser) return;
    
    // Feature gate: Check admin controls for non-owners
    if (!isOwner) {
      if (!hasAdminControls) {
        toast.error("Admin controls require a Premium plan.");
        router.push("/pricing");
        return;
      }
    }

    setBusy(true);
    const token = typeof window !== "undefined" ? localStorage.getItem("bearer_token") : null;
    await fetch(`/api/comments/${node.id}`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ userId: currentUser.id }),
    });
    setBusy(false);
    onChanged();
  };

  return (
    <div style={indentStyle} className="group">
      <div className="rounded-md border border-border p-3">
        <div className="flex items-start gap-3">
          <Avatar className="h-8 w-8 mt-0.5">
            <AvatarImage src={node.user.avatar || undefined} />
            <AvatarFallback>{node.user.name.charAt(0).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-sm">
              <span className="font-medium truncate max-w-[160px]">{node.user.name}</span>
              <span className="text-muted-foreground">• {timeAgo(node.createdAt)}</span>
            </div>
            <p className="mt-1 text-[15px] whitespace-pre-wrap break-words">{node.text}</p>
            <div className="mt-2 flex items-center gap-2">
              <Button variant="secondary" size="sm" onClick={upvote} disabled={busy}>
                <ArrowBigUp className="h-4 w-4 mr-1" /> {node.upvotes}
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setReplying((r) => !r)}>
                <MessageSquare className="h-4 w-4 mr-1" /> Reply
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setCollapsed((c) => !c)}>
                {collapsed ? (
                  <>
                    <ChevronRight className="h-4 w-4 mr-1" /> Expand
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-4 w-4 mr-1" /> Collapse
                  </>
                )}
              </Button>
              {canDelete && (
                <Button variant="ghost" size="sm" onClick={remove} disabled={busy} className="text-red-600 hover:text-red-700">
                  <Trash2 className="h-4 w-4 mr-1" /> Delete
                  {!isOwner && <Crown className="h-3 w-3 ml-1" />}
                </Button>
              )}
            </div>

            <AnimatePresence initial={false}>
              {replying && !collapsed && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mt-3">
                  <Textarea value={replyText} onChange={(e) => setReplyText(e.target.value)} placeholder="Write a reply..." />
                  <div className="flex items-center gap-2 mt-2">
                    <Button size="sm" onClick={submitReply} disabled={!replyText.trim() || busy}>
                      Reply
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setReplying(false)}>
                      Cancel
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {!collapsed && node.replies?.length > 0 && (
          <div className="mt-3 space-y-3">
            {node.replies.map((r) => (
              <CommentItem key={r.id} node={r} depth={depth + 1} onChanged={onChanged} currentUser={currentUser} customer={customer} checkFeature={checkFeature} trackUsage={trackUsage} refetchCustomer={refetchCustomer} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}