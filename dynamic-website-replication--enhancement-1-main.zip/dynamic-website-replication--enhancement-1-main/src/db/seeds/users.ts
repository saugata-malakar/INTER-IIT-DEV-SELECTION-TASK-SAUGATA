import { db } from '@/db';
import { users } from '@/db/schema';

async function main() {
    const existing = await db.select().from(users).limit(1);
    if (existing.length > 0) {
        console.log('⚠️ Users already exist, skipping seeding');
        return;
    }

    const sampleUsers = [
        {
            name: 'Admin User',
            email: 'admin@example.com',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
            isAdmin: true,
            createdAt: new Date().toISOString(),
        },
        {
            name: 'Alice Johnson',
            email: 'alice@example.com',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alice',
            isAdmin: false,
            createdAt: new Date().toISOString(),
        },
        {
            name: 'Bob Smith',
            email: 'bob@example.com',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bob',
            isAdmin: false,
            createdAt: new Date().toISOString(),
        },
        {
            name: 'Carol White',
            email: 'carol@example.com',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=carol',
            isAdmin: false,
            createdAt: new Date().toISOString(),
        },
        {
            name: 'David Brown',
            email: 'david@example.com',
            avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=david',
            isAdmin: false,
            createdAt: new Date().toISOString(),
        },
    ];

    await db.insert(users).values(sampleUsers);
    
    console.log('✅ Users seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});