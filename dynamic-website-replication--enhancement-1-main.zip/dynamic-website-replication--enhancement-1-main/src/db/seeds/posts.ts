import { db } from '@/db';
import { posts } from '@/db/schema';

async function main() {
    const existing = await db.select().from(posts).limit(1);
    if (existing.length > 0) {
        console.log('✅ Posts already exist, skipping seeder');
        return;
    }

    const samplePosts = [
        {
            title: 'Understanding Nested Comments: A Deep Dive',
            coverUrl: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=800',
            content: 'Nested comments are a powerful feature that allows users to have threaded discussions. This post explores the architecture and implementation of nested comment systems, including database design, tree structures, and sorting strategies. We\'ll look at how to handle deeply nested conversations while maintaining performance and user experience.',
            createdAt: new Date().toISOString(),
        }
    ];

    await db.insert(posts).values(samplePosts);
    
    console.log('✅ Posts seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});