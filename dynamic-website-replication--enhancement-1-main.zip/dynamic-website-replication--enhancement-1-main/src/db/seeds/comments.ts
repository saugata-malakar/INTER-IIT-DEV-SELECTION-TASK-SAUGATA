import { db } from '@/db';
import { comments } from '@/db/schema';

async function main() {
    const existing = await db.select().from(comments).limit(1);
    if (existing.length > 0) {
        console.log('⏭️  Comments already exist, skipping seeder');
        return;
    }

    const now = Date.now();
    const hoursAgo = (hours: number) => new Date(now - (hours * 60 * 60 * 1000)).toISOString();
    const daysAgo = (days: number) => new Date(now - (days * 24 * 60 * 60 * 1000)).toISOString();

    const sampleComments = [
        {
            id: 1,
            postId: 1,
            parentId: null,
            userId: 2,
            text: "Great article! I've been looking for a good explanation of nested comments.",
            upvotes: 15,
            createdAt: daysAgo(2),
        },
        {
            id: 2,
            postId: 1,
            parentId: null,
            userId: 3,
            text: "This is exactly what I needed for my project. Thanks for sharing!",
            upvotes: 8,
            createdAt: daysAgo(1),
        },
        {
            id: 3,
            postId: 1,
            parentId: null,
            userId: 4,
            text: "Could you elaborate more on the sorting strategies?",
            upvotes: 5,
            createdAt: hoursAgo(18),
        },
        {
            id: 4,
            postId: 1,
            parentId: 1,
            userId: 1,
            text: "Thanks Alice! Glad you found it helpful. Let me know if you have any questions.",
            upvotes: 10,
            createdAt: hoursAgo(36),
        },
        {
            id: 5,
            postId: 1,
            parentId: 1,
            userId: 5,
            text: "I implemented something similar and ran into performance issues with deeply nested trees.",
            upvotes: 7,
            createdAt: daysAgo(1),
        },
        {
            id: 6,
            postId: 1,
            parentId: 2,
            userId: 2,
            text: "You're welcome! Let me know how your project goes.",
            upvotes: 4,
            createdAt: hoursAgo(20),
        },
        {
            id: 7,
            postId: 1,
            parentId: 3,
            userId: 1,
            text: "Sure! There are three main sorting strategies: top (by upvotes), new (by date), and replies (by engagement). Each has its use cases.",
            upvotes: 12,
            createdAt: hoursAgo(16),
        },
        {
            id: 8,
            postId: 1,
            parentId: 4,
            userId: 3,
            text: "What about handling really deep nesting? Is there a limit you'd recommend?",
            upvotes: 6,
            createdAt: daysAgo(1),
        },
        {
            id: 9,
            postId: 1,
            parentId: 5,
            userId: 1,
            text: "Performance is definitely a concern. I recommend using pagination and lazy loading for deeply nested branches.",
            upvotes: 8,
            createdAt: hoursAgo(22),
        },
        {
            id: 10,
            postId: 1,
            parentId: 5,
            userId: 4,
            text: "Have you tried using materialized path or closure tables?",
            upvotes: 3,
            createdAt: hoursAgo(18),
        },
        {
            id: 11,
            postId: 1,
            parentId: 7,
            userId: 4,
            text: "That's really helpful! Thanks for the clarification.",
            upvotes: 5,
            createdAt: hoursAgo(14),
        },
    ];

    await db.insert(comments).values(sampleComments);
    
    console.log('✅ Comments seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});