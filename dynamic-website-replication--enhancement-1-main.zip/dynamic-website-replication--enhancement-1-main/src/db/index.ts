import { drizzle } from 'drizzle-orm/libsql';
import { createClient } from '@libsql/client';
import * as schema from '@/db/schema';

// Graceful fallback: if TURSO_CONNECTION_URL is missing/invalid, use local SQLite file
const rawUrl = process.env.TURSO_CONNECTION_URL;
const isBadUrl = !rawUrl || /^npm i\b/i.test(rawUrl) || !/^(libsql|file):/.test(rawUrl);
const client = createClient({
  url: isBadUrl ? 'file:./drizzle/dev.db' : rawUrl!,
  authToken: isBadUrl ? undefined : process.env.TURSO_AUTH_TOKEN,
});

export const db = drizzle(client, { schema });

export type Database = typeof db;

// Ensure minimal schema exists at runtime (for local/dev without migrations)
export async function ensureSchema() {
  try {
    await client.execute(`PRAGMA foreign_keys = ON;`);
    await client.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        avatar TEXT,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
      );
    `);
    await client.execute(`
      CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        cover_url TEXT,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    `);
    await client.execute(`
      CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id INTEGER NOT NULL,
        parent_id INTEGER,
        user_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        upvotes INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY(post_id) REFERENCES posts(id),
        FOREIGN KEY(parent_id) REFERENCES comments(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
      );
    `);
    await client.execute(`
      CREATE TABLE IF NOT EXISTS comment_upvotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        comment_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(comment_id) REFERENCES comments(id),
        FOREIGN KEY(user_id) REFERENCES users(id)
      );
    `);

    // Seed a default post with id=1 if it doesn't exist
    await client.execute(`
      INSERT INTO posts (id, title, cover_url, content, created_at)
      SELECT 1,
             'Introducing Bridge Comments',
             'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=1200',
             'Bridge Comments showcases a modern, nested commenting experience with sorting, voting, and admin controls. Start the discussion below!',
             datetime('now')
      WHERE NOT EXISTS (SELECT 1 FROM posts WHERE id = 1);
    `);
  } catch (e) {
    // best-effort; ignore to avoid crashing in prod
  }
}